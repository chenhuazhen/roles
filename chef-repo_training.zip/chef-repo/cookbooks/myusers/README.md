# myusers

Cookbook for creating users and groups on centos and windows for DevOps Foundations Chef course. 

Data bags are included for testing in test/data_bags.

